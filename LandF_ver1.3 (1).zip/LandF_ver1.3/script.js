document.addEventListener('DOMContentLoaded', function() {
    // Debug logs
    console.log('Script loaded');
    
    // Modal elements
    const modal = document.getElementById('lostPollModal');
    const locationModal = document.getElementById('locationModal');
    const commentModal = document.getElementById('commentModal');
    const foundReportModal = document.getElementById('foundReportModal');
    
    // Button elements
    const lostButton = document.querySelector('.lost-button');
    const foundButton = document.querySelector('.found-button');
    const closeButton = document.querySelector('.close-button');
    const cancelButton = document.querySelector('.cancel-button');
    const closeLocationButton = document.getElementById('closeLocationModal');
    const cancelLocationButton = document.getElementById('cancelLocation');
    const closeCommentButton = document.getElementById('closeCommentModal');
    const closeFoundButton = document.getElementById('closeFoundModal');
    const cancelFoundButton = document.getElementById('cancelFound');

    // Form elements
    const lostPollForm = document.querySelector('.lost-poll-form');
    const foundReportForm = document.querySelector('.found-report-form');

    // File input elements
    const fileInput = document.getElementById('visual-proof');
    const filePreview = document.querySelector('.file-preview');
    const foundFileInput = document.getElementById('visual-proof-found');
    const foundFilePreview = document.getElementById('found-file-preview');

    // Global variables
    let map, marker, selectedLocation;
    let currentPollCard = null;
    let currentPollId = 1;
    let activeForm = null;
    let isAdminMode = false;
    const ADMIN_CREDENTIALS = {
        username: 'admin',
        password: 'admin123'
    };
    let adminMails = [];
    let unreadMailCount = 0;

    // Initialize map
    function initMap() {
        if (map) {
            map.remove();
        }
        map = L.map('map').setView([22.3193, 114.1694], 13);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);

        // Clear existing marker
        if (marker) {
            marker.remove();
        }

        map.on('click', async function(e) {
            console.log('Map clicked:', e.latlng);
            if (marker) {
                marker.remove();
            }
            marker = L.marker(e.latlng).addTo(map);
            
            try {
                const address = await getAddressFromCoordinates(e.latlng.lat, e.latlng.lng);
                selectedLocation = address;
                marker.bindPopup(address).openPopup();
                console.log('Selected location:', selectedLocation);
            } catch (error) {
                console.error('Error getting address:', error);
                selectedLocation = `${e.latlng.lat.toFixed(6)}, ${e.latlng.lng.toFixed(6)}`;
            }
        });
    }

    // Function to get address from coordinates
    async function getAddressFromCoordinates(lat, lng) {
        try {
            const response = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`);
            const data = await response.json();
            
            const address = [];
            if (data.address) {
                if (data.address.building) address.push(data.address.building);
                if (data.address.road) address.push(data.address.road);
                if (data.address.suburb) address.push(data.address.suburb);
                if (data.address.city || data.address.town) address.push(data.address.city || data.address.town);
                if (data.address.state) address.push(data.address.state);
            }
            
            return address.join(', ') || `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
        } catch (error) {
            console.error('Geocoding error:', error);
            return `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
        }
    }

    // Get current location
    function getCurrentLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(async (position) => {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                
                if (marker) {
                    marker.remove();
                }
                
                map.setView([lat, lng], 16);
                marker = L.marker([lat, lng]).addTo(map);
                
                try {
                    const address = await getAddressFromCoordinates(lat, lng);
                    selectedLocation = address;
                    marker.bindPopup(address).openPopup();
                    console.log('Current location set:', selectedLocation);
                } catch (error) {
                    console.error('Error getting address:', error);
                    selectedLocation = `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
                }
            }, (error) => {
                console.error('Error getting location:', error);
                showNotification('Unable to get current location', 'error');
            });
        } else {
            showNotification('Geolocation is not supported by your browser', 'error');
        }
    }
        // Modal event listeners
        lostButton.addEventListener('click', () => {
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
            activeForm = 'lost';
        });
    
        foundButton.addEventListener('click', () => {
            console.log('Found button clicked');
            foundReportModal.classList.add('active');
            document.body.style.overflow = 'hidden';
            activeForm = 'found';
            updatePollIdDropdown();
        });
    
        // Function to update Poll ID dropdown
        function updatePollIdDropdown() {
            const pollIdSelect = document.getElementById('foundPollId');
            const pollCards = document.querySelectorAll('.poll-card:not(.found-report)');
            
            pollIdSelect.innerHTML = '<option value="">Select a Poll ID</option>';
            
            pollCards.forEach(card => {
                const pollId = card.dataset.pollId;
                const title = card.querySelector('.card-title')?.textContent || 'Unknown Item';
                const option = document.createElement('option');
                option.value = pollId;
                option.textContent = `${pollId} - ${title}`;
                pollIdSelect.appendChild(option);
            });
        }
    
        // Close functions
        function closeModal() {
            modal.classList.remove('active');
            document.body.style.overflow = 'auto';
            activeForm = null;
            document.getElementById('captchaAnswer').value = '';
        }
    
        function closeLocationModal() {
            locationModal.classList.remove('active');
            if (!modal.classList.contains('active') && !foundReportModal.classList.contains('active')) {
                document.body.style.overflow = 'auto';
            }
        }
    
        function closeCommentModal() {
            commentModal.classList.remove('active');
            document.body.style.overflow = 'auto';
            currentPollCard = null;
        }
    
        function closeFoundModal() {
            foundReportModal.classList.remove('active');
            document.body.style.overflow = 'auto';
            activeForm = null;
        }
    
        // Close button event listeners
        closeButton.addEventListener('click', closeModal);
        cancelButton.addEventListener('click', closeModal);
        closeLocationButton.addEventListener('click', closeLocationModal);
        cancelLocationButton.addEventListener('click', closeLocationModal);
        closeCommentButton.addEventListener('click', closeCommentModal);
        closeFoundButton.addEventListener('click', closeFoundModal);
        cancelFoundButton.addEventListener('click', closeFoundModal);
    
        // Modal overlay click handlers
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModal();
        });
    
        locationModal.addEventListener('click', (e) => {
            if (e.target === locationModal) closeLocationModal();
        });
    
        commentModal.addEventListener('click', (e) => {
            if (e.target === commentModal) closeCommentModal();
        });
    
        foundReportModal.addEventListener('click', (e) => {
            if (e.target === foundReportModal) closeFoundModal();
        });
    
        // Location button handling
        document.querySelector('.gps-button').addEventListener('click', () => {
            console.log('Lost poll GPS button clicked');
            activeForm = 'lost';
            locationModal.classList.add('active');
            setTimeout(() => {
                if (!map) {
                    initMap();
                } else {
                    map.invalidateSize();
                }
            }, 100);
        });
    
        document.querySelector('.found-gps-button').addEventListener('click', () => {
            console.log('Found report GPS button clicked');
            activeForm = 'found';
            locationModal.classList.add('active');
            setTimeout(() => {
                if (!map) {
                    initMap();
                } else {
                    map.invalidateSize();
                }
            }, 100);
        });
    
        document.getElementById('currentLocationBtn').addEventListener('click', getCurrentLocation);
    
        document.getElementById('confirmLocation').addEventListener('click', () => {
            console.log('Confirm location clicked. Active form:', activeForm);
            if (selectedLocation) {
                const locationInput = activeForm === 'found' ? 
                    document.getElementById('foundLocation') : 
                    document.getElementById('location');
                
                console.log('Setting location for:', activeForm);
                console.log('Location input:', locationInput);
                console.log('Selected location:', selectedLocation);
                
                if (locationInput) {
                    locationInput.value = selectedLocation;
                    closeLocationModal();
                } else {
                    console.error('Location input not found');
                    showNotification('Error setting location', 'error');
                }
            } else {
                showNotification('Please select a location on the map', 'error');
            }
        });
    
        // File upload handling
        function handleFileUpload(files, previewElement) {
            previewElement.innerHTML = '';
            for (let file of files) {
                if (file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const img = document.createElement('img');
                        img.src = e.target.result;
                        previewElement.appendChild(img);
                    }
                    reader.readAsDataURL(file);
                } else {
                    const fileIcon = document.createElement('div');
                    fileIcon.className = 'file-icon';
                    fileIcon.innerHTML = `
                        <i class="fas fa-file"></i>
                        <span>${file.name.slice(0, 10)}${file.name.length > 10 ? '...' : ''}</span>
                    `;
                    previewElement.appendChild(fileIcon);
                }
            }
        }
    
        fileInput.addEventListener('change', function(e) {
            handleFileUpload(this.files, filePreview);
        });
    
        foundFileInput.addEventListener('change', function(e) {
            handleFileUpload(this.files, foundFilePreview);
        });

            // Lost Poll form handling
    async function handleLostPollSubmit(e) {
        e.preventDefault();
        console.log('Lost Poll form submitted');

        const requiredFields = lostPollForm.querySelectorAll('[required]');
        let isValid = true;
        let firstInvalidField = null;

        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                isValid = false;
                field.classList.add('invalid');
                if (!firstInvalidField) firstInvalidField = field;
            } else {
                field.classList.remove('invalid');
            }
        });

        if (!isValid) {
            firstInvalidField.focus();
            showNotification('Please fill in all required fields', 'error');
            return;
        }

        const formData = {
            objectName: document.getElementById('objectName').value,
            category: document.getElementById('category').value,
            location: document.getElementById('location').value,
            datetime: document.getElementById('datetime').value,
            description: document.getElementById('description').value,
            contact: document.getElementById('contact').value,
            reward: document.getElementById('reward').value,
            files: []
        };

        if (fileInput.files.length > 0) {
            for (let file of fileInput.files) {
                if (file.type.startsWith('image/')) {
                    const imageUrl = await new Promise((resolve) => {
                        const reader = new FileReader();
                        reader.onload = (e) => resolve(e.target.result);
                        reader.readAsDataURL(file);
                    });
                    formData.files.push({
                        type: 'image',
                        url: imageUrl,
                        name: file.name
                    });
                } else {
                    formData.files.push({
                        type: 'file',
                        name: file.name
                    });
                }
            }
        }

        const pollsGrid = document.getElementById('pollsGrid');
        const card = createPollCard(formData);
        pollsGrid.insertBefore(card, pollsGrid.firstChild);

        showNotification('Poll created successfully!', 'success');
        lostPollForm.reset();
        filePreview.innerHTML = '';
        closeModal();
    }

    // Remove any existing event listeners and add the new one
    lostPollForm.removeEventListener('submit', handleLostPollSubmit);
    lostPollForm.addEventListener('submit', handleLostPollSubmit);

    // Found Report form handling
    foundReportForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const requiredFields = foundReportForm.querySelectorAll('[required]');
        let isValid = true;
        let firstInvalidField = null;

        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                isValid = false;
                field.classList.add('invalid');
                if (!firstInvalidField) firstInvalidField = field;
            } else {
                field.classList.remove('invalid');
            }
        });

        if (!isValid) {
            firstInvalidField.focus();
            showNotification('Please fill in all required fields', 'error');
            return;
        }

        try {
            const formData = {
                pollId: document.getElementById('foundPollId').value,
                location: document.getElementById('foundLocation').value,
                datetime: document.getElementById('foundDatetime').value,
                description: document.getElementById('foundDescription').value,
                contact: document.getElementById('finderContact').value,
                files: []
            };

            if (foundFileInput.files.length > 0) {
                for (let file of foundFileInput.files) {
                    if (file.type.startsWith('image/')) {
                        const imageUrl = await new Promise((resolve) => {
                            const reader = new FileReader();
                            reader.onload = (e) => resolve(e.target.result);
                            reader.readAsDataURL(file);
                        });
                        formData.files.push({
                            type: 'image',
                            url: imageUrl,
                            name: file.name
                        });
                    } else {
                        formData.files.push({
                            type: 'file',
                            name: file.name
                        });
                    }
                }
            }

            const pollsGrid = document.getElementById('pollsGrid');
            const card = createFoundReportCard(formData);
            pollsGrid.insertBefore(card, pollsGrid.firstChild);

            showNotification('Report submitted successfully!', 'success');
            foundReportForm.reset();
            foundFilePreview.innerHTML = '';
            closeFoundModal();
        } catch (error) {
            console.error('Error:', error);
            showNotification('Failed to submit report. Please try again.', 'error');
        }
    });

    // Create poll card function
    function createPollCard(pollData) {
        const card = document.createElement('div');
        card.className = 'poll-card';
        
        const pollId = `POLL-${String(currentPollId++).padStart(4, '0')}`;
        card.dataset.pollId = pollId;
        
        let filesHTML = '';
        if (pollData.files && pollData.files.length > 0) {
            filesHTML = `
                <div class="card-images">
                    ${pollData.files.map(file => {
                        if (file.type === 'image') {
                            return `<img src="${file.url}" alt="Preview" class="card-image-preview">`;
                        } else {
                            return `
                                <div class="file-icon">
                                    <i class="fas fa-file"></i>
                                    <span>${file.name.slice(0, 10)}${file.name.length > 10 ? '...' : ''}</span>
                                </div>
                            `;
                        }
                    }).join('')}
                </div>
            `;
        }
        
        card.innerHTML = `
            <div class="card-content">
                <div class="card-header">
                    <span class="card-status">Lost Poll</span>
                    <span class="poll-id">${pollId}</span>
                </div>
                <h3 class="card-title">${pollData.objectName}</h3>
                <span class="card-category">${pollData.category}</span>
                ${filesHTML}
                <div class="card-details">
                    <div class="card-detail-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>${pollData.location}</span>
                    </div>
                    <div class="card-detail-item">
                        <i class="fas fa-calendar-alt"></i>
                        <span>${new Date(pollData.datetime).toLocaleString()}</span>
                    </div>
                    <div class="card-detail-item">
                        <i class="fas fa-phone"></i>
                        <span>${pollData.contact}</span>
                    </div>
                    ${pollData.reward ? `
                        <div class="card-detail-item">
                            <i class="fas fa-gift"></i>
                            <span>Reward: ${pollData.reward}</span>
                        </div>
                    ` : ''}
                </div>
                <p class="card-description">${pollData.description}</p>
                <div class="card-actions">
                    <div class="button-group">
                        <button class="contact-button">Contact</button>
                        <button class="comment-button">
                            <i class="fas fa-comment"></i> Comments
                        </button>
                    </div>
                    <div class="social-share">
                        <button class="share-button facebook" title="Share on Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </button>
                        <button class="share-button twitter" title="Share on Twitter">
                            <i class="fab fa-twitter"></i>
                        </button>
                        <button class="share-button whatsapp" title="Share on WhatsApp">
                            <i class="fab fa-whatsapp"></i>
                        </button>
                        <button class="share-button telegram" title="Share on Telegram">
                            <i class="fab fa-telegram-plane"></i>
                        </button>
                    </div>
                    <span class="card-date">Posted ${new Date().toLocaleDateString()}</span>
                </div>
            </div>
        `;

        const contactButton = card.querySelector('.contact-button');
        contactButton.addEventListener('click', (e) => {
            e.preventDefault();
            const contact = pollData.contact;
            if (contact.includes('@')) {
                window.location.href = `mailto:${contact}`;
            } else {
                window.location.href = `tel:${contact}`;
            }
        });

        const commentButton = card.querySelector('.comment-button');
        commentButton.addEventListener('click', () => {
            openCommentModal(card);
        });
        
        card.comments = [];

        // Add social share event listeners
        const shareButtons = card.querySelectorAll('.share-button');
        shareButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                const platform = button.classList[1]; // facebook, twitter, etc.
                const shareText = `Lost Item Alert: ${pollData.objectName} - Lost at ${pollData.location}. Please contact if found.`;
                const shareUrl = window.location.href;

                let shareLink;
                switch(platform) {
                    case 'facebook':
                        shareLink = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareText)}`;
                        break;
                    case 'twitter':
                        shareLink = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;
                        break;
                    case 'whatsapp':
                        shareLink = `https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`;
                        break;
                    case 'telegram':
                        shareLink = `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`;
                        break;
                }

                // Open share dialog in a new window
                window.open(shareLink, '_blank', 'width=600,height=400,resizable=yes,scrollbars=yes');
            });
        });

        addDeleteButtonIfAdmin(card);

        return card;
    }

    function createFoundReportCard(formData) {
        const card = document.createElement('div');
        card.className = 'poll-card found-report';
        
        // Get the details from the original lost poll
        const originalPoll = document.querySelector(`.poll-card[data-poll-id="${formData.pollId}"]`);
        const category = originalPoll ? originalPoll.querySelector('.card-category').textContent : 'Unknown';
        const objectName = originalPoll ? originalPoll.querySelector('.card-title').textContent : 'Unknown Item';
        
        let filesHTML = '';
        if (formData.files && formData.files.length > 0) {
            filesHTML = `
                <div class="card-images">
                    ${formData.files.map(file => {
                        if (file.type === 'image') {
                            return `<img src="${file.url}" alt="Preview" class="card-image-preview">`;
                        } else {
                            return `
                                <div class="file-icon">
                                    <i class="fas fa-file"></i>
                                    <span>${file.name.slice(0, 10)}${file.name.length > 10 ? '...' : ''}</span>
                                </div>
                            `;
                        }
                    }).join('')}
                </div>
            `;
        }
        
        card.innerHTML = `
            <div class="card-content">
                <div class="card-header">
                    <span class="card-status">Found Report</span>
                    <span class="poll-id">For ${formData.pollId}</span>
                </div>
                <h3 class="card-title">${objectName}</h3>
                <span class="card-category">${category}</span>
                <div class="card-details">
                    <div class="card-detail-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>${formData.location}</span>
                    </div>
                    <div class="card-detail-item">
                        <i class="fas fa-calendar-alt"></i>
                        <span>${new Date(formData.datetime).toLocaleString()}</span>
                    </div>
                    <div class="card-detail-item">
                        <i class="fas fa-phone"></i>
                        <span>${formData.contact}</span>
                    </div>
                </div>
                ${filesHTML}
                <p class="card-description">${formData.description}</p>
                <div class="card-actions">
                    <div class="button-group">
                        <button class="contact-button">Contact Finder</button>
                        <button class="comment-button">
                            <i class="fas fa-comment"></i> Comments
                        </button>
                    </div>
                    <span class="card-date">Reported ${new Date().toLocaleDateString()}</span>
                </div>
            </div>
        `;
    
        // Add contact button handler
        const contactButton = card.querySelector('.contact-button');
        contactButton.addEventListener('click', (e) => {
            e.preventDefault();
            const contact = formData.contact;
            if (contact.includes('@')) {
                window.location.href = `mailto:${contact}`;
            } else {
                window.location.href = `tel:${contact}`;
            }
        });
    
        // Add comment button handler
        const commentButton = card.querySelector('.comment-button');
        commentButton.addEventListener('click', () => {
            openCommentModal(card);
        });
        
        // Initialize comments array
        card.comments = [];

        addDeleteButtonIfAdmin(card);

        return card;
    }

    // Comment system
    function openCommentModal(card) {
        currentPollCard = card;
        const commentsList = commentModal.querySelector('.comments-list');
        commentsList.innerHTML = '';
        
        if (card.comments && card.comments.length > 0) {
            card.comments.forEach(comment => {
                const commentElement = document.createElement('div');
                commentElement.className = 'comment';
                commentElement.innerHTML = `
                    <div class="comment-header">
                        <span class="commenter-name">${comment.name}</span>
                        <span class="comment-date">${comment.date}</span>
                    </div>
                    <p class="comment-text">${comment.text}</p>
                `;
                commentsList.appendChild(commentElement);
            });
        }
        
        commentModal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    const commentForm = document.querySelector('.comment-form');
    commentForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        if (currentPollCard) {
            const commentText = document.getElementById('commentText').value;
            const commenterName = document.getElementById('commenterName').value;
            
            if (!commentText.trim() || !commenterName.trim()) {
                showNotification('Please fill in all fields', 'error');
                return;
            }
            
            const comment = {
                text: commentText,
                name: commenterName,
                date: new Date().toLocaleString()
            };
            
            if (!currentPollCard.comments) {
                currentPollCard.comments = [];
            }
            
            currentPollCard.comments.push(comment);
            
            showNotification('Comment added successfully!', 'success');
            commentForm.reset();
            openCommentModal(currentPollCard);
        }
    });

    // Notification handling
    function showNotification(message, type = 'success') {
        const notification = document.getElementById('notification');
        const messageElement = notification.querySelector('.notification-message');
        const iconElement = notification.querySelector('.notification-icon');
        
        messageElement.textContent = message;
        notification.className = `notification ${type}`;
        
        iconElement.className = 'notification-icon fas ' + 
            (type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle');
        
        notification.classList.add('active');
        
        setTimeout(() => {
            notification.classList.remove('active');
        }, 3000);
    }

    // Initialize admin features
    const adminLoginBtn = document.getElementById('adminLoginBtn');
    const adminModal = document.getElementById('adminModal');
    const closeAdminModal = document.getElementById('closeAdminModal');
    const cancelAdminLogin = document.getElementById('cancelAdminLogin');
    const adminLoginForm = document.getElementById('adminLoginForm');

    // Add click event for admin login button
    adminLoginBtn.addEventListener('click', (e) => {
        e.preventDefault();
        console.log('Admin button clicked');
        if (isAdminMode) {
            handleAdminLogout();
        } else {
            adminModal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    });

    // Add click events for closing modal
    closeAdminModal.addEventListener('click', () => {
        closeAdminLoginModal();
    });

    cancelAdminLogin.addEventListener('click', () => {
        closeAdminLoginModal();
    });

    // Add submit event for login form
    adminLoginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        handleAdminLogin();
    });

    // Close modal when clicking outside
    adminModal.addEventListener('click', (e) => {
        if (e.target === adminModal) {
            closeAdminLoginModal();
        }
    });

    function closeAdminLoginModal() {
        adminModal.classList.remove('active');
        document.body.style.overflow = 'auto';
        adminLoginForm.reset();
    }

    function handleAdminLogin() {
        const username = document.getElementById('adminUsername').value;
        const password = document.getElementById('adminPassword').value;

        console.log('Login attempt:', username);

        if (username === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password) {
            isAdminMode = true;
            document.body.classList.add('admin-mode');
            adminMailbox.classList.add('visible');
            showNotification('Admin login successful', 'success');
            closeAdminLoginModal();
            refreshDeleteButtons();
            refreshMailbox();
            updateAdminButton();
        } else {
            showNotification('Invalid credentials', 'error');
        }
    }

    function handleAdminLogout() {
        isAdminMode = false;
        document.body.classList.remove('admin-mode');
        adminMailbox.classList.remove('visible');
        showNotification('Admin logged out', 'success');
        refreshDeleteButtons();
        updateAdminButton();
    }

    function updateAdminButton() {
        if (isAdminMode) {
            adminLoginBtn.innerHTML = '<i class="fas fa-user-shield"></i> Logout';
        } else {
            adminLoginBtn.innerHTML = '<i class="fas fa-user-shield"></i> Admin';
        }
    }

    function refreshDeleteButtons() {
        const allCards = document.querySelectorAll('.poll-card');
        allCards.forEach(card => {
            const existingButton = card.querySelector('.delete-button');
            if (existingButton) {
                existingButton.remove();
            }
            
            if (isAdminMode) {
                const deleteButton = document.createElement('button');
                deleteButton.className = 'delete-button';
                deleteButton.innerHTML = '<i class="fas fa-trash"></i>';
                deleteButton.addEventListener('click', () => confirmDelete(card));
                card.appendChild(deleteButton);
            }
        });
    }

    function confirmDelete(card) {
        const confirmation = document.createElement('div');
        confirmation.className = 'delete-confirmation';
        confirmation.innerHTML = `
            <p>Are you sure you want to delete this ${card.classList.contains('found-report') ? 'found report' : 'lost poll'}?</p>
            <div class="button-group">
                <button class="cancel-delete">Cancel</button>
                <button class="confirm-delete">Delete</button>
            </div>
        `;

        document.body.appendChild(confirmation);

        const cancelBtn = confirmation.querySelector('.cancel-delete');
        const confirmBtn = confirmation.querySelector('.confirm-delete');

        cancelBtn.addEventListener('click', () => {
            confirmation.remove();
        });

        confirmBtn.addEventListener('click', () => {
            card.remove();
            confirmation.remove();
            showNotification('Item deleted successfully', 'success');
        });
    }

    // Modify createPollCard and createFoundReportCard to include delete button
    function addDeleteButtonIfAdmin(card) {
        if (isAdminMode) {
            const deleteButton = document.createElement('button');
            deleteButton.className = 'delete-button';
            deleteButton.innerHTML = '<i class="fas fa-trash"></i>';
            deleteButton.addEventListener('click', () => confirmDelete(card));
            card.appendChild(deleteButton);
        }
    }

    // Search functionality
    const searchInput = document.querySelector('.search-input');
    const searchButton = document.querySelector('.search-button');
    const categorySelect = document.querySelector('.category-select');

    function performSearch() {
        const searchTerm = searchInput.value.toLowerCase().trim();
        const selectedCategory = categorySelect.value;
        console.log('Searching for:', searchTerm, 'in category:', selectedCategory);

        const allCards = document.querySelectorAll('.poll-card');
        console.log('Total cards found:', allCards.length);

        allCards.forEach(card => {
            const titleElement = card.querySelector('.card-title');
            const categoryElement = card.querySelector('.card-category');
            
            const objectName = titleElement ? titleElement.textContent.toLowerCase() : '';
            const cardCategory = categoryElement ? categoryElement.textContent.toLowerCase() : '';

            const matchesSearch = searchTerm === '' || objectName.includes(searchTerm);
            const matchesCategory = selectedCategory === '' || cardCategory.toLowerCase() === selectedCategory.toLowerCase();

            console.log('Card category:', cardCategory, 'Selected category:', selectedCategory, 'Matches:', matchesCategory);

            if (matchesSearch && matchesCategory) {
                card.style.display = '';
                console.log('Match found - showing card');
            } else {
                card.style.display = 'none';
                console.log('No match - hiding card');
            }
        });
    }

    // Search on button click
    searchButton.addEventListener('click', (e) => {
        e.preventDefault();
        console.log('Search button clicked');
        performSearch();
    });

    // Search when Enter key is pressed
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            console.log('Enter key pressed');
            performSearch();
        }
    });

    // Perform search when category changes
    categorySelect.addEventListener('change', () => {
        console.log('Category changed');
        performSearch();
    });

    // Clear search and show all cards when search input is empty
    searchInput.addEventListener('input', () => {
        if (searchInput.value === '') {
            console.log('Search cleared');
            performSearch();
        }
    });

    // Initialize mail system
    const contactAdminBtn = document.getElementById('contactAdminBtn');
    const contactAdminModal = document.getElementById('contactAdminModal');
    const closeContactModal = document.getElementById('closeContactModal');
    const cancelContact = document.getElementById('cancelContact');
    const contactAdminForm = document.getElementById('contactAdminForm');
    const adminMailbox = document.getElementById('adminMailbox');
    const mailAttachment = document.getElementById('mailAttachment');
    const mailFilePreview = document.getElementById('mailFilePreview');

    // Add this function to update the poll ID dropdown
    function updateContactFormPollIds() {
        const pollIdSelect = document.getElementById('relatedPollId');
        const allCards = document.querySelectorAll('.poll-card');
        
        pollIdSelect.innerHTML = '<option value="">Select a Poll ID</option>';
        
        allCards.forEach(card => {
            const pollId = card.dataset.pollId;
            const title = card.querySelector('.card-title')?.textContent || 'Unknown Item';
            const type = card.classList.contains('found-report') ? 'Found Report' : 'Lost Poll';
            
            const option = document.createElement('option');
            option.value = pollId;
            option.textContent = `${pollId} - ${title} (${type})`;
            pollIdSelect.appendChild(option);
        });
    }

    // Modify the contact button click handler
    contactAdminBtn.addEventListener('click', () => {
        console.log('Contact button clicked');
        contactAdminModal.classList.add('active');
        document.body.style.overflow = 'hidden';
        updateContactFormPollIds();
    });

    // Close modal handlers
    closeContactModal.addEventListener('click', closeContactAdminModal);
    cancelContact.addEventListener('click', closeContactAdminModal);
    contactAdminModal.addEventListener('click', (e) => {
        if (e.target === contactAdminModal) closeContactAdminModal();
    });

    // Form submission
    contactAdminForm.addEventListener('submit', handleMailSubmission);

    function closeContactAdminModal() {
        contactAdminModal.classList.remove('active');
        document.body.style.overflow = 'auto';
        contactAdminForm.reset();
        mailFilePreview.innerHTML = '';
    }

    // Add file preview handler with improved error handling
    mailAttachment.addEventListener('change', function(e) {
        console.log('File selected:', this.files[0]); // Debug log
        mailFilePreview.innerHTML = '';
        const file = this.files[0];
        
        if (file) {
            try {
                if (file.type.startsWith('image/')) {
                    // Handle image files
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const img = document.createElement('img');
                        img.src = e.target.result;
                        img.alt = file.name;
                        mailFilePreview.appendChild(img);
                    }
                    reader.onerror = function(error) {
                        console.error('Error reading file:', error);
                        showNotification('Error reading file', 'error');
                    }
                    reader.readAsDataURL(file);
                } else {
                    // Handle other file types
                    const fileIcon = document.createElement('div');
                    fileIcon.className = 'file-icon';
                    fileIcon.innerHTML = `
                        <i class="fas fa-file"></i>
                        <span>${file.name.slice(0, 15)}${file.name.length > 15 ? '...' : ''}</span>
                    `;
                    mailFilePreview.appendChild(fileIcon);
                }
                
                // Show success notification
                showNotification('File attached successfully', 'success');
            } catch (error) {
                console.error('Error handling file:', error);
                showNotification('Error handling file', 'error');
            }
        }
    });

    // Update the mail submission handler to properly handle files
    async function handleMailSubmission(e) {
        e.preventDefault();
        
        try {
            const file = mailAttachment.files[0];
            let attachment = null;

            if (file) {
                attachment = await new Promise((resolve, reject) => {
                    const reader = new FileReader();
                    reader.onload = (e) => resolve({
                        type: file.type,
                        name: file.name,
                        data: e.target.result
                    });
                    reader.onerror = reject;
                    reader.readAsDataURL(file);
                });
            }

            const mail = {
                id: Date.now(),
                sender: document.getElementById('senderEmail').value,
                subject: document.getElementById('mailSubject').value,
                content: document.getElementById('mailContent').value,
                pollId: document.getElementById('relatedPollId').value,
                attachment: attachment,
                date: new Date().toLocaleString(),
                unread: true
            };

            adminMails.unshift(mail);
            unreadMailCount++;
            updateMailCounter();
            
            showNotification('Message sent successfully!', 'success');
            closeContactAdminModal();
            
            if (isAdminMode) {
                refreshMailbox();
            }
        } catch (error) {
            console.error('Error submitting mail:', error);
            showNotification('Error sending message', 'error');
        }
    }

    function updateMailCounter() {
        const adminBtn = document.getElementById('adminLoginBtn');
        let counter = adminBtn.querySelector('.mail-counter');
        
        if (unreadMailCount > 0) {
            if (!counter) {
                counter = document.createElement('span');
                counter.className = 'mail-counter';
                adminBtn.style.position = 'relative';
                adminBtn.appendChild(counter);
            }
            counter.textContent = unreadMailCount;
        } else if (counter) {
            counter.remove();
        }
    }

    function refreshMailbox() {
        const mailList = document.getElementById('mailList');
        mailList.innerHTML = '';
        
        if (adminMails.length === 0) {
            mailList.innerHTML = '<p class="no-mails">No messages yet</p>';
            return;
        }

        adminMails.forEach((mail, index) => {
            const mailItem = document.createElement('div');
            mailItem.className = `mail-item ${mail.unread ? 'unread' : ''}`;
            mailItem.innerHTML = `
                <div class="mail-header">
                    <span class="mail-sender">${mail.sender}</span>
                    <span class="mail-date">${mail.date}</span>
                    <button class="delete-mail-button"><i class="fas fa-trash"></i></button>
                </div>
                <div class="mail-subject">
                    ${mail.subject}
                    ${mail.pollId ? `<span class="mail-poll-id">(Poll ID: ${mail.pollId})</span>` : ''}
                </div>
                <div class="mail-preview">${mail.content}</div>
                <div class="mail-content">
                    ${mail.content}
                    ${mail.attachment ? `
                        <div class="mail-attachment">
                            ${mail.attachment.type.startsWith('image/') 
                                ? `<img src="${mail.attachment.data}" alt="Attachment">` 
                                : `<div class="file-icon">
                                    <i class="fas fa-file"></i>
                                    <span>${mail.attachment.name}</span>
                                   </div>`
                            }
                        </div>
                    ` : ''}
                </div>
            `;

            // Add click event for expanding mail
            mailItem.addEventListener('click', (e) => {
                if (!e.target.closest('.delete-mail-button')) {
                    if (mail.unread) {
                        mail.unread = false;
                        unreadMailCount--;
                        updateMailCounter();
                        mailItem.classList.remove('unread');
                    }
                    mailItem.classList.toggle('expanded');
                }
            });

            // Add delete functionality
            const deleteButton = mailItem.querySelector('.delete-mail-button');
            deleteButton.addEventListener('click', (e) => {
                e.stopPropagation();
                adminMails.splice(index, 1);
                if (mail.unread) {
                    unreadMailCount--;
                    updateMailCounter();
                }
                refreshMailbox();
                showNotification('Message deleted', 'success');
            });

            mailList.appendChild(mailItem);
        });
    }
});